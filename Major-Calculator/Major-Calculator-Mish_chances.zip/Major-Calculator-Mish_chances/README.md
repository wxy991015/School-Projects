# Major-Calculator
The final project for our Intro to ITWS class. Created by Michelle Leung, Max Wei, and Andrew Piszek
